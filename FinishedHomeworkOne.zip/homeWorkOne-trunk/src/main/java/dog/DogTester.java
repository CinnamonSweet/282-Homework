package dog;

public class DogTester {

    public static void main(String[] args) {
        //Bluey exists now and functions, followed the comments
        Dog bluey = new Dog("Australian Cattle Dog","Bluey");
        System.out.println(bluey);
    }
}
